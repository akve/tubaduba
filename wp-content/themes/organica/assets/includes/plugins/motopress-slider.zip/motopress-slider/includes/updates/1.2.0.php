<?php
if (!defined('ABSPATH')) exit;

MPSLAdmin::createTables();